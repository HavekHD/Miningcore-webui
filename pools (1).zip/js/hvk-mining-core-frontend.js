/*
 * Module description:
 * Custom frontend middleware. Retrieves and stores data from Mining Core backend. 
 *
 * Documentation for this module can be found at: [link].
 * ---
 * 
 * Version: 0.1.0
 * ---
 * 
 * Original Author: 
 * Robert Lopez - https://robertlopez.me
 * ---
 * 
 * Contributors:
 * [add your name & contact details here if you edit this file]
 * ---
 *
 * Notes:
 * This is the first version of this script. Code should be kept decoupled from the HTML on the frontend.
 *
 */

var HVK = HVK || {};
const { createApp } = Vue;

/**
 * Website URL
 */
HVK.url = document.location.origin + document.location.pathname;

/**
 * API
 */
HVK.api =  "http://api.rabidpools.net:4000/api/";

/**
 * Stratum Address
 */
HVK.stratumAddress = "havek.net";

/**
 * Current Pool
 */
HVK.currentPool = null;

/**
 * Initize
 */
HVK.Constructor = {

    hashList: window.location.hash.split(/[#/?=]/),

    ready: function(){
        this.getCurrentPool();
        HVK.MinersDashboard.loadWalletStats();
    },

    getCurrentPool: function(){
        HVK.currentPool = this.hashList[1];
    }

}

/**
 * Utilities
 */
HVK.Utilities = {

    // General formatter function
    formatter : function (value, decimal, unit) {
        if (value === 0) {
        return "0 " + unit;
        } else {
        var si = [
            { value: 1, symbol: "" },
            { value: 1e3, symbol: "k" },
            { value: 1e6, symbol: "M" },
            { value: 1e9, symbol: "G" },
            { value: 1e12, symbol: "T" },
            { value: 1e15, symbol: "P" },
            { value: 1e18, symbol: "E" },
            { value: 1e21, symbol: "Z" },
            { value: 1e24, symbol: "Y" }
        ];
        for (var i = si.length - 1; i > 0; i--) {
            if (value >= si[i].value) {
            break;
            }
        }
        return ((value / si[i].value).toFixed(decimal).replace(/\.0+$|(\.[0-9]*[1-9])0+$/, "$1") + " " + si[i].symbol + unit);
        }
    }

};

/**
 * Miners Dashboard
 */
HVK.MinersDashboard = createApp({

    data() {
        return {
            walletAddress : null,
            data: {},
            workerAvgs: {},
            workerTotals: {}
        }
    },
    methods: {

        /**
         * Loads Round Worker Stats
         */
        loadWalletStats: function(range = ""){

            if(!this.walletAddress){
                this.walletAddress = $("#walletAddress").val();
            }
            var self = this;
            $.ajax(API + "pools/" + HVK.currentPool + "/miners/" + this.walletAddress + range)
            .done(function(data) {
                self.data = data;

                // Calculate Worker Stats Averages
                self.calculateAvgs();

                // Calculate the totals
                self.calculateTotals();
            })
            .fail(function() {
                $.notify({
                    message: "Error: No response from API.<br>(loadDashboardWorkerList)"
                },{
                    type: "danger",
                    timer: 3000
                });
            });  

        },

        /**
         * Calculate Worker Stats Averages
         */
        calculateAvgs: function(){

            let workers = Object.keys(this.data.performance.workers);

            this.workerAvgs = {};

            for (let i = 0; i < workers.length; i++) {
                this.workerAvgs[workers[i]] = {
                    "hashrate": 0,
                    "shares": 0,
                    "rejectedShares": 0,
                    "eff": 0,
                    "roundShare": 0,
                    "blocksFound": 0,
                    "blocks": 0,
                    "avgEffort": 0,
                    "pendingEarnings": 0,
                    "confirmedEarnings": 0,
                    "paid": 0
                };
            }

            // Add up stats
            for (let i = 0; i < this.data.performanceSamples.length; i++) {

                for (let key in this.data.performanceSamples[i].workers) {

                    for (let index in this.workerAvgs[key]) {
                        this.workerAvgs[key][index] = this.workerAvgs[key][index] + this.data.performanceSamples[i].workers[key][index];
                    }
                
                }
                
            }

            // Divide stats to get average
            for (let worker in this.workerAvgs) {

                let count = 0;

                // count
                for (let i = 0; i < this.data.performanceSamples.length; i++) {
                    if (this.data.performanceSamples[i].workers[worker]){
                        count++;
                    }
                }

                for (let index in this.workerAvgs[worker]) {
                    this.workerAvgs[worker][index] = this.workerAvgs[worker][index] / count;
                }
            
            }

            // Add share data
            for (let worker in this.workerAvgs) {
                
                this.workerAvgs[worker].shares = this.data.shares.workers[worker].accepted
            
            }

        },

        /**
         * Calculate Worker Stats Totals
         */
        calculateTotals: function(){

            this.workerTotals = {
                "hashrate": 0,
                "shares": 0,
                "rejectedShares": 0,
                "eff": 0,
                "roundShare": 0,
                "blocksFound": 0,
                "blocks": 0,
                "avgEffort": 0,
                "pendingEarnings": 0,
                "confirmedEarnings": 0,
                "paid": 0
            };

            for (let worker in this.workerAvgs) {

                for (let index in this.workerAvgs[worker]) {
                    this.workerTotals[index] = this.workerTotals[index] + this.workerAvgs[worker][index];
                }
            
            }

        },

        /**
         * Loads Worker Stats in Round
         */
        loadWalletStatsRound: function(){
            this.loadWalletStats("?perfMode=Round");
        },

        /**
         * Loads Worker Stats in last 24 hours
         */
        loadWalletStats24: function(){
            this.loadWalletStats();
        },

        /**
         * Loads Worker Stats in last 30 days
         */
        loadWalletStats30: function(){
            this.loadWalletStats("?perfMode=Month");
        },

        /**
         * Loads Lifetime Worker Stats
         */
        loadWalletStatsAll: function(){
            this.loadWalletStats("?perfMode=All");
        },

        formatHashRate: function(val){
            return HVK.Utilities.formatter(val, 2, "H/s");
        },

        formatSharesNum: function(val){
            let num = (Math.round(val * 100) / 100).toFixed(2);
            let nf = new Intl.NumberFormat('en-US');
            return nf.format(num);
        }

    },
    created(){

        var walletQueryString = window.location.hash.split(/[#/?]/)[3];
        if (walletQueryString) {
            var wallet = window.location.hash.split(/[#/?]/)[3].replace("address=", "");
            if (wallet) {
                this.walletAddress = wallet;
            }
        }

    }

}).mount('#miners-dashboard');

/**
 * Invoke ready() & load() modules
 */
$(function(){

    for(Module in HVK){
        try{
            HVK[Module].ready();
        }catch(E){
            if (!!window.console && ~location.hash.search('debug')) console.log(E);
        }
    }

    $(window).load(function(){
        for(Module in HVK){
            try{
                HVK[Module].load();
            }catch(E){
                if (!!window.console && ~location.hash.search('debug')) console.log(E);
            }
        }
    })
});